'use strict';

var NAMESPACE;
void (function (NAMESPACE) {
    
    //App object
    var app = {
		init: function(){}
	};
	//Init app
	app.init();
}(NAMESPACE || (NAMESPACE = {})));