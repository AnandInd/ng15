'use strict';

var NAMESPACE;
void (function(NAMESPACE) {

    // App object
    var app = {
		init: function() {

			app.triggerAnimations();
			// Scroll to
			$('.learn-more-link').click(app.scrollTo);

			// Carousel Defaults
			$('.carousel').carousel({
				interval: false
			});

			// Timeline animations
			$(window).scroll(app.animateTimeline);

		},
		looper: function(id, linkName, name, bool) {
			var list = document.getElementById(id);
			var listNode;
			var i;

			if (bool) {
				for (i = 0; i < name.length; i++) {
					list.innerHTML += "<li><a target='_blank' href=" + linkName[i] + ">" + name[i] + "</a></li>"
				}
			} else {
				for (i = 0; i < name.length; i++) {
					list.innerHTML += "<li><a target='_blank' href=" + linkName[i] + ">" + name[i] + "</a></li>"
				}
			}

		},
		setWelcomeText: function(text, source) {
			var welcomeNode = document.getElementsByClassName(text)[0];
			welcomeNode.innerHTML += source;
		},
		animateFeatures: function() {
			$('.features .panel').each(function(index) {
				$(this).delay(500).queue(function() { $(this).removeClass('none').addClass('fadeIn'); });
			});
		},
		animateHeaders: function() {
			$('.slide .slide-headings').each(function(index) {
				$(this).delay(1500).queue(function(){
					$(this).removeClass('none').addClass('fadeInDown');
				});
			});

			$('.carousel-indicators').delay(500).queue(function(){
				$(this).removeClass('none').addClass('fadeInDown');
			});
		},
		animateTimeline: function() {
			var first = true;
			var second = true;
			if (first && $(this).scrollTop() > 500) {
				$('.timeline-left > .timeline-item').each(function(index) {
					$(this).delay(300 * index).queue(function() { $(this).removeClass('none').addClass('fadeInLeft'); });
				});
				$('.timeline-right > .timeline-item').each(function(index) {
					$(this).delay(300 * index).queue(function() { $(this).removeClass('none').addClass('fadeInRight'); });
				});
				first = false;

			}

			if(second  && $(this).scrollTop() > 1100){
				app.animateAwards();
			}
		},
		login: function() {

			// Plain fade to login box
			$('.slide-pre').fadeOut(200, function() {
				$('.slide-post').fadeIn(200);
			});
		},
		scrollTo: function() {
			$('html,body').animate({
				scrollTop: $("#main").offset().top
			});
		},
		triggerAnimations: function(){

			//Animate the laoding cover
			$('.cover').delay(500).queue(function(){
				
				//Add fade out class
				$(this).addClass('zero');

				//Hide Cover
				setTimeout(function() {
			      $('.cover').addClass('hidden');
			      console.log(123465789);
			     }, 1500);

				//Run next set of on load animations
				runNext();
			});

			//Trigger next animations
			function runNext(){
				
				// Feature animations
				app.animateFeatures();

				//jumbotron animations
				app.animateHeaders();
			}
		},
		animateAwards: function(){
			
			$('.dashboard img').delay(500, function() {
				
				//slideInUp or slowUpSlide
				$('.dashboard img').removeClass('none').addClass('slideInUp')
			});
		}
	};

	// Init app
	app.init();
} (NAMESPACE || (NAMESPACE = {})));