import * as angular from 'angular';

export class FileService {
	public static $inject = ['$http'];
	public loading: boolean;
	public files: string[];
	private $http: angular.IHttpService;

	constructor($http: angular.IHttpService) {
		this.$http = $http;
		this.files = [];
	}

	public loadFiles(): angular.IPromise<string[]> {
		this.loading = true;
		var request = this.$http.get<string[]>('/json/files.json');

		request.then(response => {
			this.files = response.data;
			this.loading = false;
		});

		return request;
	}

	public addFile(file): angular.IPromise<boolean> {
		return this.$http.get<boolean>('/json/files.json', file); // Should use post
	}
}

angular.module('app.modules.files.services.file', [])
	.service('fileService', FileService);
