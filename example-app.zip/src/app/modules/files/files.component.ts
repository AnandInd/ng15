import * as angular from 'angular';
import './services/file.service';
import {FileService} from './services/file.service';
import './create-file/create-file.component';

export class FilesComponent {
	public static $inject = ['fileService', '$uibModal'];
	public fileService: FileService;
	private $uibModal: angular.ui.bootstrap.IModalService;

	constructor(fileService: FileService, $uibModal: angular.ui.bootstrap.IModalService) {
		this.fileService = fileService;
		this.$uibModal = $uibModal;

		this.fileService.loadFiles();
	}

	public createFile() {
		this.$uibModal.open({
			template: '<create-file close="$ctrl.close()"></create-file>',
			controllerAs: '$ctrl',
			controller: ['$uibModalInstance', function($uibModalInstance: angular.ui.bootstrap.IModalServiceInstance) {
				this.close = function() {
					$uibModalInstance.close();
				};
			}]
		});
	}
}

angular.module('app.modules.files', ['app.modules.files.services.file', 'app.modules.files.create-file'])
	.component('files', {
		bindings: {
		},
		controller: FilesComponent,
		template: require('./files.html')
	});
