import * as angular from 'angular';
import 'angular-ui-router';
import {IStateProvider, IUrlRouterProvider} from 'angular-ui-router';


angular.module('app').config([
	'$stateProvider',
	'$urlRouterProvider',
	'PERMISSIONS',
	function($stateProvider: IStateProvider,
		$urlRouterProvider: IUrlRouterProvider) {

		$stateProvider
			.state('files', {
				url: '/files',
				template: '<files></files>',
				data: {
					menu: {
						name: 'Files',
						icon: 'fa-download',
						showSubmenu: true
					}
				}
			});
	}]);
