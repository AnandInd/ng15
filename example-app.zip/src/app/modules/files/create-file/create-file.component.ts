import * as angular from 'angular';
import '../services/file.service';
import {FileService} from '../services/file.service';

export class CreateFileComponent {
	public static $inject = ['fileService'];
	public fileService: FileService;
	public disableButton: boolean;
	public close: () => void;

	constructor(fileService: FileService) {
		this.fileService = fileService;
	}

	public createFile() {
		this.disableButton = true;
		this.fileService.addFile('newfile').then(() => {
			this.disableButton = false;
			this.fileService.loadFiles();			
			this.close();
		});	
	}
}

angular.module('app.modules.files.create-file', ['app.modules.files.services.file'])
	.component('createFile', {
		bindings: {
			close: '&'
		},
		controller: CreateFileComponent,
		template: require('./create-file.html')
	});
