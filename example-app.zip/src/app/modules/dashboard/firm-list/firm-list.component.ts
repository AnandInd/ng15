import * as angular from 'angular';
import '../services/firm.service';
import {FirmService} from '../services/firm.service';

export class FirmListComponent {
	public static $inject = ['firmService'];
	public firmService: FirmService;

	constructor(firmService: FirmService) {
		// Constructor	
		this.firmService = firmService;
		
		firmService.loadFirms();
	}
}

angular.module('app.modules.dashboard.firm-list', ['app.modules.dashboard.services.firm'])
	.component('firmList', {
		bindings: {
			title: '@'
		},
		controller: FirmListComponent,
		template: require('./firm-list.html')
	});
