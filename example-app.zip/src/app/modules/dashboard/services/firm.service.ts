import * as angular from 'angular';

export class FirmService {
	public static $inject = ['$http'];
	public loading: boolean;
	public firms: any[];
	private $http: angular.IHttpService;

	constructor($http: angular.IHttpService) {
		this.$http = $http;
		this.firms = [];
	}

	public loadFirms(): angular.IPromise<any[]> {
		this.loading = true;
		var request = this.$http.get<any[]>('/json/firms.json');

		request.then(response => {
			this.firms = response.data;
			this.loading = false;
		});

		return request;
	}
}

angular.module('app.modules.dashboard.services.firm', [])
	.service('firmService', FirmService);
