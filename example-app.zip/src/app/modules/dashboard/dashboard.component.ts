import * as angular from 'angular';
import './firm-list/firm-list.component';

export class DashboardComponent {
	public static $inject = [];	

	constructor() {
		// Constructor
	}
}

angular.module('app.modules.dashboard', [
	'app.modules.dashboard.firm-list'
])
	.component('dashboard', {
		bindings: {
		},
		controller: DashboardComponent,
		template: require('./dashboard.html')
	});
