import * as angular from 'angular';

export class AnalyticsComponent {
	public static $inject = [];
	public charts: any;

	constructor() {
		// Constructor	
		
		this.charts = {};			

		this.charts.assetDistribution =  {
			chart: {
					numberPrefix: '\u0024',
					theme: 'zune',
					'showLabels': '0',       
					'enableSmartLabels': '0',
					'showValues': '0',
					'showLegend': '0'
				},
				'categories': [
				{
					'category': [
						{
							'label': 'Jan'
						},
						{
							'label': 'Feb'
						},
						{
							'label': 'Mar'
						},
						{
							'label': 'Apr'
						},
						{
							'label': 'May'
						},
						{
							'label': 'Jun'
						},
						{
							'label': 'Jul'
						},
						{
							'label': 'Aug'
						},
						{
							'label': 'Sep'
						},
						{
							'label': 'Oct'
						},
						{
							'label': 'Nov'
						},
						{
							'label': 'Dec'
						}
					]
				}
			],
			'dataset': [
				{
					'seriesname': 'Actual Revenue',
					'renderas': 'area',
					'data': [
						{
							'value': '16000'
						},
						{
							'value': '20000'
						},
						{
							'value': '18000'
						},
						{
							'value': '19000'
						},
						{
							'value': '15000'
						},
						{
							'value': '21000'
						},
						{
							'value': '16000'
						},
						{
							'value': '20000'
						},
						{
							'value': '17000'
						},
						{
							'value': '25000'
						},
						{
							'value': '19000'
						},
						{
							'value': '23000'
						}
					]
				},
				{
					'seriesname': 'Projected Revenue',
					'renderas': 'area',					
					'showvalues': '0',
					'data': [
						{
							'value': '19000'
						},
						{
							'value': '23000'
						},
						{
							'value': '19000'
						},
						{
							'value': '36000'
						},
						{
							'value': '21000'
						},
						{
							'value': '25000'
						},
						{
							'value': '26000'
						},
						{
							'value': '30000'
						},
						{
							'value': '27000'
						},
						{
							'value': '23000'
						},
						{
							'value': '28000'
						},
						{
							'value': '39000'
						}
					]
				},
				{
					'seriesname': 'Profit',	
					'renderas': 'area',				
					'showvalues': '0',
					'data': [
						{
							'value': '4000'
						},
						{
							'value': '5000'
						},
						{
							'value': '3000'
						},
						{
							'value': '4000'
						},
						{
							'value': '1000'
						},
						{
							'value': '7000'
						},
						{
							'value': '1000'
						},
						{
							'value': '4000'
						},
						{
							'value': '1000'
						},
						{
							'value': '8000'
						},
						{
							'value': '2000'
						},
						{
							'value': '7000'
						}
					]
				}
			]
		};
		
		this.charts.regionDistribution = {
			chart: {
				numberPrefix: '\u0024',
						theme: 'zune',
						'showLabels': '0',       
						'enableSmartLabels': '0',
						'showValues': '0',
						'showLegend': '0',
						pieRadius: 80
				},
			data: [
				{
					'label': 'ANZ',
					'value': '12.3'
				},
				{
					'label': 'APAC',
					'value': '240.3'
				},
				{
					'label': 'EMEA',
					'value': '154.3'
				},
				{
					'label': 'LAM',
					'value': '86.7'
				},
				{
					'label': 'USA',
					'value': '135.2'
				}
		]};
		
		this.charts.locationDistribution = {
			chart: {
					numberPrefix: '\u0024',
					theme: 'zune',
					'showLabels': '0',       
					'enableSmartLabels': '0',
					'showValues': '0',
					'showLegend': '0'
				},
				'categories': [
				{
					'category': [
						{
							'label': 'Jan'
						},
						{
							'label': 'Feb'
						},
						{
							'label': 'Mar'
						},
						{
							'label': 'Apr'
						},
						{
							'label': 'May'
						},
						{
							'label': 'Jun'
						},
						{
							'label': 'Jul'
						},
						{
							'label': 'Aug'
						},
						{
							'label': 'Sep'
						},
						{
							'label': 'Oct'
						},
						{
							'label': 'Nov'
						},
						{
							'label': 'Dec'
						}
					]
				}
			],
			'dataset': [
				{
					'seriesname': 'Actual Revenue',
					'data': [
						{
							'value': '16000'
						},
						{
							'value': '20000'
						},
						{
							'value': '18000'
						},
						{
							'value': '19000'
						},
						{
							'value': '15000'
						},
						{
							'value': '21000'
						},
						{
							'value': '16000'
						},
						{
							'value': '20000'
						},
						{
							'value': '17000'
						},
						{
							'value': '25000'
						},
						{
							'value': '19000'
						},
						{
							'value': '23000'
						}
					]
				},
				{
					'seriesname': 'Projected Revenue',					
					'showvalues': '0',
					'data': [
						{
							'value': '15000'
						},
						{
							'value': '16000'
						},
						{
							'value': '17000'
						},
						{
							'value': '18000'
						},
						{
							'value': '19000'
						},
						{
							'value': '19000'
						},
						{
							'value': '19000'
						},
						{
							'value': '19000'
						},
						{
							'value': '20000'
						},
						{
							'value': '21000'
						},
						{
							'value': '22000'
						},
						{
							'value': '23000'
						}
					]
				},
				{
					'seriesname': 'Profit',					
					'showvalues': '0',
					'data': [
						{
							'value': '4000'
						},
						{
							'value': '5000'
						},
						{
							'value': '3000'
						},
						{
							'value': '4000'
						},
						{
							'value': '1000'
						},
						{
							'value': '7000'
						},
						{
							'value': '1000'
						},
						{
							'value': '4000'
						},
						{
							'value': '1000'
						},
						{
							'value': '8000'
						},
						{
							'value': '2000'
						},
						{
							'value': '7000'
						}
					]
				}
			]
		};
	}
}

angular.module('app.modules.analytics', [
])
	.component('analytics', {
		bindings: {
		},
		controller: AnalyticsComponent,
		template: require('./analytics.html')
	});
