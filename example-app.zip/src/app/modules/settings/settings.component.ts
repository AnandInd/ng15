import * as angular from 'angular';

export class SettingsComponent {
	public static $inject = [];
	public states: any[];
	public user: any;

	constructor() {
		this.states = [{ name: 'California', value: 'CA' }, { name: 'New York', value: 'NY' }];

		this.user = {};
		this.user.firstname = 'John';
		this.user.lastname = 'Smith';
		this.user.email = 'john.smith@moodys.com';
		this.user.phone = '555-123-3456';
		this.user.city = 'San Francisco';
		this.user.state = this.states[0];
		this.user.zip = '94105';
		this.user.description = 'This is a longer description';
	}
}

angular.module('app.modules.settings', [])
	.component('settings', {
		bindings: {
		},
		controller: SettingsComponent,
		template: require('./settings.html')
	});
