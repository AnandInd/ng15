import * as angular from 'angular';

import '../../services/localization.service';
import {LocalizationService} from '../../services/localization.service';
import '../../components/language-selector/language-selector.component';

export class LocalizationComponent {
	public static $inject = ['localizationService'];
	public currentLocale: string;
	public numberExample: number;
	public dateExample: Date;

	constructor(localizationService: LocalizationService) {
		this.currentLocale = localizationService.getCurrentLocale();
		this.numberExample = 1000000;
		this.dateExample = new Date();
	}
}

angular.module('app.modules.localization', [
	'app.components.language-selector',
	'app.services.localization'
])
	.component('localization', {
		bindings: {
		},
		controller: LocalizationComponent,
		template: require('./localization.html')
	});
