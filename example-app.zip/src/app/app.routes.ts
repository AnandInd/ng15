import * as angular from 'angular';
import 'angular-ui-router';
import {IStateProvider, IUrlRouterProvider} from 'angular-ui-router';
import './services/auth.service';
import {AuthService} from './services/auth.service';
import './app.permissions.ts';
import {Permissions} from './app.permissions.ts';

angular.module('app').config([
	'$stateProvider',
	'$urlRouterProvider',
	function($stateProvider: IStateProvider,
		$urlRouterProvider: IUrlRouterProvider,
		PERMISSIONS: Permissions) {

		// Index
		$urlRouterProvider.when('', '/dashboard');

		// App Routing
		$stateProvider
			.state('dashboard', {
				url: '/dashboard',
				template: '<dashboard></dashboard>',
				data: {
					menu: {
						name: 'navigation.dashboard',
						icon: 'fa-dashboard'
					}
				}
			}).state('analytics', {
				url: '/analytics',
				template: '<analytics></analytics>',
				data: {
					menu: {
						name: 'Analytics',
						icon: 'fa-bar-chart'
					}
				}
			}).state('localization', {
				url: '/localization',
				template: '<localization></localization>',
				data: {
					menu: {
						name: 'navigation.localization',
						icon: 'fa-calculator'
					}
				}
			}).state('401', {
				url: '/401',
				template: '<div class="absolute-center"><h1>401</h1><p class="lead">Access not authorized to this page.</p></div>'
			}).state('403', {
				url: '/403',
				template: '<div class="absolute-center"><h1>403</h1><p class="lead">Access not authorized to this page.</p></div>'
			}).state('404', {
				url: '/404',
				template: '<div class="absolute-center"><h1>404</h1><p class="lead">Sorry but we couldn’t find the page you are looking for.</p></div>'
			});

		// 404 for missing routes
		$urlRouterProvider.otherwise('/404');
	}]);

// Module Specific Routes

import 'modules/files/files.routes';
import 'modules/settings/settings.routes';

// Route Authentication

angular.module('app').run(['$rootScope', '$state', 'authService',
	function($rootScope: angular.IRootScopeService, $state, authService: AuthService) {
		// Handles unauthorized error for state changes	
		$rootScope.$on('$stateChangeStart', function(event, toState, toParams, fromState, fromParams, options) {
			if (toState.data && toState.data.permissions) {
				var permission = toState.data.permissions;
				if (!authService.hasAllPermissions(permission)) {
					event.preventDefault();
					$state.go('401');
				}
			}
		});

		// Handles unauthorized error for $http requests to API/services 
		$rootScope.$on('unauthenticated', (event, data) => {
			if (data.status === 401) {
				$state.go('401');
			} else if (data.status === 403) {
				$state.go('404');
			}
		});
	}]);
