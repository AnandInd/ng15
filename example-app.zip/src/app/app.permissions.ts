import * as angular from 'angular';

angular.module('app').constant('PERMISSIONS', {
	permission1: 'permission1',
	permission2: 'permission2',
	permission3: 'permission3',
	permissionx: 'permissionx'
});

export interface Permissions {
	permission1: string;
	permission2: string;
	permission3: string;
	permissionx: string;
}
