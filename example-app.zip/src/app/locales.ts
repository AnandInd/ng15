import 'file?name=locales/angular-locale_en-us.js!angular-i18n/angular-locale_en-us.js';
import 'file?name=locales/angular-locale_fr-fr.js!angular-i18n/angular-locale_fr-fr.js';
import 'file?name=locales/angular-locale_ru-ru.js!angular-i18n/angular-locale_ru-ru.js';
import 'file?name=locales/angular-locale_zh-cn.js!angular-i18n/angular-locale_zh-cn.js';
