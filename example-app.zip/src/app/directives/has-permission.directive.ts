import * as angular from 'angular';
import '../services/auth.service';
import {AuthService} from '../services/auth.service';

angular.module('app.directives.has-permission', ['app.services.auth'])
	.directive('hasPermission', ['authService', function(authService: AuthService) {
		return {
			restrict: 'EA',
			replace: false,
			scope: {},
			link: function(scope, element, attrs) {
				if (authService.hasPermission(attrs.hasPermission)) {
					element.show();
				} else {
					element.hide();
				}
			}
		};
	}]);
