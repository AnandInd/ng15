import * as angular from 'angular';

export class AuthService {
	public static $inject = [];
	private user: any;

	constructor() {
		// User info/permissions are loaded from window.user set in app.html
		// to load this from json you will need to use angular.bootstrap and load before app initializes.
		this.user = (<any>window).user;
	}

	public setUser(user: any): void {
		this.user = user;
	}

	public getUser(): any {
		return this.user;
	}

	public hasPermission(permission: string): boolean {
		var hasPermission = false;

		if (this.user.permissions === null) {
			return hasPermission;
		}

		angular.forEach(this.user.permissions, function(value) {
			if (value === permission) {
				hasPermission = true;
			}
		});

		return hasPermission;
	}

	public hasAllPermissions(permissions: string[]): boolean {
		var hasAllPermissions = true;
		var atLeastOnePermission = false;

		angular.forEach(permissions, (value) => {
			if (this.hasPermission(value)) {
				atLeastOnePermission = true;
			} else {
				hasAllPermissions = false;
			}
		});

		return hasAllPermissions && atLeastOnePermission;
	}
}

angular.module('app.services.auth', [])
	.service('authService', AuthService);
