import 'app.module';
import 'app.routes';
import 'app.locales';
import 'app.localization';
