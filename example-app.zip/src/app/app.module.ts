// CSS
import 'css/app.scss';

// Angular Libs

import 'angular';
import 'angular-ui-router';
import 'ui-router-extras';
import 'angular-cookies';
import 'angular-animate';
import 'angular-messages';
import 'angular-sanitize';
import 'angular-dynamic-locale';
import 'angular-translate';
import 'angular-translate-loader-static-files';
import 'angular-translate-handler-log';
import 'angular-translate-storage-cookie';
import 'angular-jwt';

// Galileo Components

import 'lodash';
import 'file?name=jquery.min.js!jquery/dist/jquery.min.js';
import 'angular-ui-bootstrap';
import 'file?name=ag-grid.js!ag-grid/dist/ag-grid.js';
import 'ers-bootstrap-dropdown';
import 'ers-ui-components/ers-ui-components-with-tpls.js';

// App Services

import './services/auth.service';

// App Components

import './components/layout/header-bar/header-bar.component';
import './components/layout/left-nav/left-nav.component';

// App Modules

import './modules/dashboard/dashboard.component';
import './modules/analytics/analytics.component';
import './modules/localization/localization.component';
import './modules/files/files.component';
import './modules/settings/settings.component';

var app = angular.module('app', [
	// Vendor
	'ui.router',
	'angular-jwt',
	'ngCookies',
	'ngAnimate',
	'pascalprecht.translate',
	'tmh.dynamicLocale',
	'ers.components.all',
	// App Services
	'app.services.auth',
	// App Components
	'app.components.layout.header-bar',
	'app.components.layout.left-nav',
	// App Modules
	'app.modules.dashboard',
	'app.modules.analytics',
	'app.modules.localization',
	'app.modules.files',
	'app.modules.settings'
]);

app.config(['$compileProvider', '$httpProvider', 'jwtInterceptorProvider',
	function($compileProvider, $httpProvider, jwtInterceptorProvider) {
		// Disabled debug information for performance
		$compileProvider.debugInfoEnabled(false);

		// Configure JWT Token for HTTP requests		
		let checkTokenExpiration = false;

		jwtInterceptorProvider.tokenGetter = ['jwtHelper', '$http', '$location', 'config', function(jwtHelper, $http, $location, config) {
			// Return token for API calls
			if (config.url.indexOf('localhost/api') > -1) {
				let token = localStorage.getItem('token');

				if (token && (!checkTokenExpiration || !jwtHelper.isTokenExpired(token))) {
					return token;
				} else {
					return $http({
						url: '/json/jwt.json',
						skipAuthorization: true,
						method: 'GET'
					}).then(response => {
						let newToken = response.data.token;
						localStorage.setItem('token', newToken);
						return newToken;
					}, response => {
						// Failed to get a new token. User is not authorized. Will need to re-login
						$location.path('/403');
					});
				}
			}

			return null;
		}];

		$httpProvider.interceptors.push('jwtInterceptor');
	}]);

exports = app.name;
