import * as angular from 'angular';
import '../../../services/menu.service';
import {MenuService} from '../../../services/menu.service';

export class LeftNavComponent {
	public static $inject = ['menuService'];
	private menuService: MenuService;
	private menuItems: any;
	private collapsed: boolean;

	constructor(menuService: MenuService) {
		this.menuService = menuService;
		this.menuItems = menuService.get({ type: 'tree' });
	}

	public toggleMenu(): void {
		this.collapsed = !this.collapsed;
	}
}

angular.module('app.components.layout.left-nav', ['app.services.menu'])
	.component('leftNav', {
		bindings: {
			collapsed: '=?'
		},
		controller: LeftNavComponent,
		template: require('./left-nav.html')
	});
