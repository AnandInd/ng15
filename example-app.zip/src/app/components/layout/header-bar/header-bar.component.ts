import * as angular from 'angular';

export class HeaderBarComponent {
	public static $inject = [];
	private collapsed: boolean;

	constructor() {
		// Controller
	}

	public toggleMenu(): void {
		this.collapsed = !this.collapsed;
	}
}

angular.module('app.components.layout.header-bar', [])
	.component('headerBar', {
		bindings: {
			collapsed: '=?'
		},
		controller: HeaderBarComponent,
		template: require('./header-bar.html')
	});
