import * as angular from 'angular';
import '../../services/localization.service';
import {LocalizationService} from '../../services/localization.service';

export class LanguageSelectorComponent {
	public static $inject = ['localizationService'];
	public locales: any;
	public currentLocale: any;
	private localizationService: LocalizationService;

	constructor(localizationService: LocalizationService) {
		this.localizationService = localizationService;
		this.locales = this.localizationService.getLocales();
		this.localeGetter();
	}

	public changeLanguage(locale) {
		this.localizationService.setLocale(locale.code);
		this.localeGetter();
	};

	private localeGetter() {
		for (var i = 0; i < this.locales.length; i++) {
			if (this.locales[i].code === this.localizationService.getCurrentLocale()) {
				this.currentLocale = this.locales[i];
			}
		}
	};
}

angular.module('app.components.language-selector', ['app.services.localization'])
	.component('languageSelector', {
		bindings: {},
		controller: LanguageSelectorComponent,
		template: require('./language-selector.html')
	});
