import * as angular from 'angular';
import 'angular-mocks';
import 'components/layout/header-bar/header-bar.component';

describe('heaaderBar', function() {

	beforeEach(angular.mock.module('app.components.layout.header-bar'));

	var $compile: angular.ICompileService;
	var $rootScope: angular.IRootScopeService;
	var $q: angular.IQService;	

	var mockFilter = function(value) {
		return value;
	};

	beforeEach(function() {
		angular.mock.module(function($provide) {
			$provide.value('translateFilter', mockFilter);
		});
	});

	beforeEach(angular.mock.inject(function(_$compile_, _$rootScope_, _$q_) {
		// The injector unwraps the underscores (_) from around the parameter names when matching
		$compile = _$compile_;
		$rootScope = _$rootScope_;
		$q = _$q_;
	}));

	it('should display the component', function() {
		// Compile a piece of HTML containing the directive
		var element = $compile('<header-bar></header-bar>')($rootScope);

		// fire all the watches
		$rootScope.$digest();

		// Check
		var html = element.html();
		expect(html).toBeTruthy();
	});	

});
