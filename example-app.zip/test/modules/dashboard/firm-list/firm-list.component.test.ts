import * as angular from 'angular';
import 'angular-mocks';
import 'modules/dashboard/firm-list/firm-list.component';

describe('firmList', function() {

	beforeEach(angular.mock.module('app.modules.dashboard.firm-list'));

	var $compile: angular.ICompileService;
	var $rootScope: angular.IRootScopeService;
	var $q: angular.IQService;
	var firmService;

	var mockFilter = function(value) {
		return value;
	};

	beforeEach(function() {
		angular.mock.module(function($provide) {
			$provide.value('translateFilter', mockFilter);
		});
	});

	beforeEach(angular.mock.inject(function(_$compile_, _$rootScope_, _$q_, _firmService_) {
		// The injector unwraps the underscores (_) from around the parameter names when matching
		$compile = _$compile_;
		$rootScope = _$rootScope_;
		$q = _$q_;
		firmService = _firmService_;
	}));

	it('should display the component', function() {
		spyOn(firmService, 'loadFirms').and.returnValue($q.when([]));

		// Compile a piece of HTML containing the directive
		var element = $compile('<firm-list></firm-list>')($rootScope);

		// fire all the watches
		$rootScope.$digest();

		// Check
		var html = element.html();
		expect(html).not.toBeFalsy();
	});

	it('should display column title', function() {
		spyOn(firmService, 'loadFirms').and.returnValue($q.when([]));
		
		// Compile a piece of HTML containing the directive
		var element = $compile('<firm-list></firm-list>')($rootScope);

		// fire all the watches
		$rootScope.$digest();

		// Check
		var html = element.html();
		expect(html).toContain('Firm Name');
	});

});
