import * as angular from 'angular';
import 'angular-mocks';
import '../../src/app/services/auth.service';
import {AuthService} from '../../src/app/services/auth.service';

describe('authService', function() {

	beforeEach(angular.mock.module('app.services.auth'));

	(<any>window).user = { name: 'Test' };
	var service: AuthService;

	beforeEach(angular.mock.inject(function(authService) {
		service = authService;
	}));

	it('can get an instance of the service', function() {
		expect(service).toBeDefined();
	});

	it('should return non-empty string', function() {
		var user = service.getUser();	

		expect(user).toBeDefined();
	});

});
