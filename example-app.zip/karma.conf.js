// Karma configuration
// Generated on Mon Jan 04 2016 09:12:41 GMT-0800 (Pacific Standard Time)

var path = require('path');

module.exports = function(config) {
	config.set({

		// base path that will be used to resolve all patterns (eg. files, exclude)
		basePath: '',

		// frameworks to use
		// available frameworks: https://npmjs.org/browse/keyword/karma-adapter
		frameworks: ['jasmine'],

		// list of files / patterns to load in the browser
		files: [
			'test/index.js'
		],

		// list of files to exclude
		exclude: [
		],

		// preprocess matching files before serving them to the browser
		// available preprocessors: https://npmjs.org/browse/keyword/karma-preprocessor
		preprocessors: {
			'test/index.js': ['webpack', 'coverage']
		},

		webpack: {
			module: {
				loaders: [
					{ test: /\.ts$/, loader: 'ts-loader' },
					{ test: /\.html$/, loader: 'raw' }
				]
			},

			resolve: {
				root: path.join(__dirname, '/src/app'),
				extensions: ['', '.ts', '.js'],
				alias:
				{
					components: 'components',
					services: 'services'
				}
			},
		},

		webpackMiddleware: {
            // webpack-dev-middleware configuration          
            noInfo: true
        },

		plugins: [
            require("karma-webpack"),
			'karma-*'
        ],
		
		// available reporters: https://npmjs.org/browse/keyword/karma-reporter
		reporters: ['progress', 'coverage', 'growl'],

		coverageReporter: { type: 'text' }, // creates console only output for test coverage report
		// coverageReporter: { type: 'html', dir: 'coverage/' }, // creates html test coverage report

		growlReporter: {
            prefix: 'UNIT TESTS-'
        },

		// web server port
		port: 9876,

		// enable / disable colors in the output (reporters and logs)
		colors: true,

		// level of logging
		// possible values: config.LOG_DISABLE || config.LOG_ERROR || config.LOG_WARN || config.LOG_INFO || config.LOG_DEBUG
		logLevel: config.LOG_INFO,

		// enable / disable watching file and executing tests whenever any file changes
		autoWatch: true,

		// start these browsers
		// available browser launchers: https://npmjs.org/browse/keyword/karma-launcher
		browsers: ['PhantomJS'],

		// Continuous Integration mode
		// if true, Karma captures browsers, runs the tests and exits
		singleRun: false,

		// Concurrency level
		// how many browser should be started simultaneous
		concurrency: Infinity
	})
}
